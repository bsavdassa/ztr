﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
namespace telefon_rehberi
{
    public partial class Form1 : Form
    {
        OleDbConnection baglanti;
        OleDbDataAdapter adapter;
        OleDbCommand komut;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }

        public void gridDoldur()
        {
            baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=rehber.accdb");
            string telefonnumarasi = cmbGosterilecekTelefon.Text;
            adapter = new OleDbDataAdapter("select * from rehber where sahibi='" + telefonnumarasi + "'", baglanti);
            dt = new DataTable();
            baglanti.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            baglanti.Close();
        }
        public void comboboxdoldur()
        {
            baglanti = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=rehber.accdb");
            adapter = new OleDbDataAdapter("select * from kisiler", baglanti);
            dt = new DataTable();
            baglanti.Open();
            adapter.Fill(dt);
            string[] telefonlar = dt.AsEnumerable().Select(x => x.Field<string>("telefon")).ToArray<string>();
            cmbGosterilecekTelefon.Items.AddRange(telefonlar);
            baglanti.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            gridDoldur();
            comboboxdoldur();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            baglanti.Open();
            komut = new OleDbCommand();
            komut.Connection = baglanti;
            komut.CommandText = "insert into rehber (numara, adsoyad, sahibi) values (@numara, @adsyoad, @sahibi)";
            komut.Parameters.AddWithValue("@numara", txtTelefonNumarasi.Text);
            komut.Parameters.AddWithValue("@adsoyad", txtAd.Text);
            komut.Parameters.AddWithValue("@sahibi", cmbGosterilecekTelefon.Text);
            komut.ExecuteNonQuery();
            baglanti.Close();
            gridDoldur();
            txtSira.Text = "";
            txtAd.Text = "";
            txtTelefonNumarasi.Text = "";
            txtSira.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            komut = new OleDbCommand();
            komut.Connection = baglanti;
            komut.CommandText = "delete from rehber where sira=@sira and sahibi=@sahibi";
            komut.Parameters.AddWithValue("@sira", txtSira.Text);
            komut.Parameters.AddWithValue("@sahibi", cmbGosterilecekTelefon.Text);
            komut.ExecuteNonQuery();
            baglanti.Close();
            gridDoldur();
            txtSira.Text = "";
            txtAd.Text = "";
            txtTelefonNumarasi.Text = "";
            txtSira.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            komut = new OleDbCommand();
            komut.Connection = baglanti;
            komut.CommandText = "update rehber set adsoyad=@adsoyad, numara=@numara where sira=@sira and sahibi=@sahibi";
            komut.Parameters.AddWithValue("@adsoyad", txtAd.Text);
            komut.Parameters.AddWithValue("@numara", txtTelefonNumarasi.Text);
            komut.Parameters.AddWithValue("@sira", txtSira.Text);
            komut.Parameters.AddWithValue("@sahibi", cmbGosterilecekTelefon.Text);
            komut.ExecuteNonQuery();
            gridDoldur();
            baglanti.Close();
            txtSira.Text = "";
            txtAd.Text = "";
            txtTelefonNumarasi.Text = "";
            txtSira.Text = "";
        }

        private void cmbGosterilecekTelefon_SelectedIndexChanged(object sender, EventArgs e)
        {
            gridDoldur();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtSira.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtTelefonNumarasi.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtAd.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }
    }
}
